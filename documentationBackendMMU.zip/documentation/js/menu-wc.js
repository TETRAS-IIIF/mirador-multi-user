'use strict';

customElements.define('compodoc-menu', class extends HTMLElement {
    constructor() {
        super();
        this.isNormalMode = this.getAttribute('mode') === 'normal';
    }

    connectedCallback() {
        this.render(this.isNormalMode);
    }

    render(isNormalMode) {
        let tp = lithtml.html(`
        <nav>
            <ul class="list">
                <li class="title">
                    <a href="index.html" data-type="index-link">untitled1 documentation</a>
                </li>

                <li class="divider"></li>
                ${ isNormalMode ? `<div id="book-search-input" role="search"><input type="text" placeholder="Type to search"></div>` : '' }
                <li class="chapter">
                    <a data-type="chapter-link" href="index.html"><span class="icon ion-ios-home"></span>Getting started</a>
                    <ul class="links">
                        <li class="link">
                            <a href="overview.html" data-type="chapter-link">
                                <span class="icon ion-ios-keypad"></span>Overview
                            </a>
                        </li>
                        <li class="link">
                            <a href="index.html" data-type="chapter-link">
                                <span class="icon ion-ios-paper"></span>README
                            </a>
                        </li>
                                <li class="link">
                                    <a href="dependencies.html" data-type="chapter-link">
                                        <span class="icon ion-ios-list"></span>Dependencies
                                    </a>
                                </li>
                                <li class="link">
                                    <a href="properties.html" data-type="chapter-link">
                                        <span class="icon ion-ios-apps"></span>Properties
                                    </a>
                                </li>
                    </ul>
                </li>
                    <li class="chapter modules">
                        <a data-type="chapter-link" href="modules.html">
                            <div class="menu-toggler linked" data-bs-toggle="collapse" ${ isNormalMode ?
                                'data-bs-target="#modules-links"' : 'data-bs-target="#xs-modules-links"' }>
                                <span class="icon ion-ios-archive"></span>
                                <span class="link-name">Modules</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                        </a>
                        <ul class="links collapse " ${ isNormalMode ? 'id="modules-links"' : 'id="xs-modules-links"' }>
                            <li class="link">
                                <a href="modules/AnnotationPageModule.html" data-type="entity-link" >AnnotationPageModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' : 'data-bs-target="#xs-controllers-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' :
                                            'id="xs-controllers-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' }>
                                            <li class="link">
                                                <a href="controllers/AnnotationPageController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AnnotationPageController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' : 'data-bs-target="#xs-injectables-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' :
                                        'id="xs-injectables-links-module-AnnotationPageModule-b5dd45ad13a91741b9774e2f80fb4fd16bf78233eeaddc9835d1dbaf3a43b9a08a27d94df76ae2d4f4c6f73dd47ab87e9570aed56a0525f647201580e5f84700"' }>
                                        <li class="link">
                                            <a href="injectables/AnnotationPageService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AnnotationPageService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/AppModule.html" data-type="entity-link" >AppModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' : 'data-bs-target="#xs-controllers-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' :
                                            'id="xs-controllers-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' }>
                                            <li class="link">
                                                <a href="controllers/AppController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AppController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' : 'data-bs-target="#xs-injectables-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' :
                                        'id="xs-injectables-links-module-AppModule-54e67269c7c4f8ab497498fded1bb516ab1061c83add8bf4d381628f8df8944fcb96eddb9f81a237bec8defdd048e3f1f344da3ccee3c913245a877b5b4d383d"' }>
                                        <li class="link">
                                            <a href="injectables/AppService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AppService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/AuthModule.html" data-type="entity-link" >AuthModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' : 'data-bs-target="#xs-controllers-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' :
                                            'id="xs-controllers-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' }>
                                            <li class="link">
                                                <a href="controllers/AuthController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AuthController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' : 'data-bs-target="#xs-injectables-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' :
                                        'id="xs-injectables-links-module-AuthModule-131a508c7dcff6d7e8e34bfc263c15f6dfaaed11fb0299692f4144ebb45d0664e4226760253c01825dcf0f720cd177cfa9d61933fb964fb807e5a4c6343770af"' }>
                                        <li class="link">
                                            <a href="injectables/AuthService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >AuthService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/EmailServerService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailServerService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/CaslModule.html" data-type="entity-link" >CaslModule</a>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-CaslModule-481afee38a024d8e14295e78cd14b96c1a18f8df7a9606398bc766bd7e0f08e5ae24708fe60cc34a3a99b8885bf1eefdcc44ab2f2d9c5d52c43f595e8125de20"' : 'data-bs-target="#xs-injectables-links-module-CaslModule-481afee38a024d8e14295e78cd14b96c1a18f8df7a9606398bc766bd7e0f08e5ae24708fe60cc34a3a99b8885bf1eefdcc44ab2f2d9c5d52c43f595e8125de20"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-CaslModule-481afee38a024d8e14295e78cd14b96c1a18f8df7a9606398bc766bd7e0f08e5ae24708fe60cc34a3a99b8885bf1eefdcc44ab2f2d9c5d52c43f595e8125de20"' :
                                        'id="xs-injectables-links-module-CaslModule-481afee38a024d8e14295e78cd14b96c1a18f8df7a9606398bc766bd7e0f08e5ae24708fe60cc34a3a99b8885bf1eefdcc44ab2f2d9c5d52c43f595e8125de20"' }>
                                        <li class="link">
                                            <a href="injectables/CaslAbilityFactory.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CaslAbilityFactory</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/EmailConfirmationModule.html" data-type="entity-link" >EmailConfirmationModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' : 'data-bs-target="#xs-controllers-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' :
                                            'id="xs-controllers-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' }>
                                            <li class="link">
                                                <a href="controllers/EmailConfirmationController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailConfirmationController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' : 'data-bs-target="#xs-injectables-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' :
                                        'id="xs-injectables-links-module-EmailConfirmationModule-5ac774b4835d77b9a0e4adf20bc0cc6689d262a0fad868703275e407dec2f5998d430ccb33e0e2edc3150409a631e7ef3c1ed8dae11d4ec69d1fdb4bc06996e2"' }>
                                        <li class="link">
                                            <a href="injectables/EmailConfirmationService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailConfirmationService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/EmailServerService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailServerService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/EmailServerModule.html" data-type="entity-link" >EmailServerModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' : 'data-bs-target="#xs-controllers-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' :
                                            'id="xs-controllers-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' }>
                                            <li class="link">
                                                <a href="controllers/EmailServerController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailServerController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' : 'data-bs-target="#xs-injectables-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' :
                                        'id="xs-injectables-links-module-EmailServerModule-548097f615fa8d9de07b3e21f7627c27ca50241e961cfe98ea7beb6781438effb7c63c2f8f3967e98ac9df7038252cd1d03058b33ffd5c4a369acc99895c4460"' }>
                                        <li class="link">
                                            <a href="injectables/EmailServerService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailServerService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/ImpersonationModule.html" data-type="entity-link" >ImpersonationModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' : 'data-bs-target="#xs-controllers-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' :
                                            'id="xs-controllers-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' }>
                                            <li class="link">
                                                <a href="controllers/ImpersonationController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ImpersonationController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' : 'data-bs-target="#xs-injectables-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' :
                                        'id="xs-injectables-links-module-ImpersonationModule-ee4f98abc414b1f7f84f215feada9932cd3899a8a6d783df72e1fcb9663604be114c2a5aa8b041100799e7a56faa87966f69af089a3570e0885f5da5b3e3bee3"' }>
                                        <li class="link">
                                            <a href="injectables/ImpersonationService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ImpersonationService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/LinkGroupProjectModule.html" data-type="entity-link" >LinkGroupProjectModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' : 'data-bs-target="#xs-controllers-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' :
                                            'id="xs-controllers-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' }>
                                            <li class="link">
                                                <a href="controllers/LinkGroupProjectController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkGroupProjectController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' : 'data-bs-target="#xs-injectables-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' :
                                        'id="xs-injectables-links-module-LinkGroupProjectModule-f0d30c1e0fab989b14aaaaf4d39725605d79a008e0184ccefabc0b734b26dcd673cdecd60d12e4f173a9824e0a7825b4e48fa1154d43e9f24f700088ab9f84e9"' }>
                                        <li class="link">
                                            <a href="injectables/LinkGroupProjectService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkGroupProjectService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/LinkManifestGroupModule.html" data-type="entity-link" >LinkManifestGroupModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' : 'data-bs-target="#xs-controllers-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' :
                                            'id="xs-controllers-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' }>
                                            <li class="link">
                                                <a href="controllers/LinkManifestGroupController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkManifestGroupController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' : 'data-bs-target="#xs-injectables-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' :
                                        'id="xs-injectables-links-module-LinkManifestGroupModule-936b64bd0a1fec3a5d153fb60032963450123290e1c03568c133ab4ef2fa430552e8708f22c9f2ddab1c9e4a10c3ea0bd8cf4f984f819f6634e15aa4c84e7a8f"' }>
                                        <li class="link">
                                            <a href="injectables/LinkManifestGroupService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkManifestGroupService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/LinkMediaGroupModule.html" data-type="entity-link" >LinkMediaGroupModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' : 'data-bs-target="#xs-controllers-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' :
                                            'id="xs-controllers-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' }>
                                            <li class="link">
                                                <a href="controllers/LinkMediaGroupController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkMediaGroupController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' : 'data-bs-target="#xs-injectables-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' :
                                        'id="xs-injectables-links-module-LinkMediaGroupModule-27db19353fd639f2959acaf8f976ddd89131d3e96efbe60869a552736d291417006b87c860ed0fa6fb1253922834e04b39f710523a92950f790f50424125df1b"' }>
                                        <li class="link">
                                            <a href="injectables/LinkMediaGroupService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkMediaGroupService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/LinkMetadataFormatGroupModule.html" data-type="entity-link" >LinkMetadataFormatGroupModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' : 'data-bs-target="#xs-controllers-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' :
                                            'id="xs-controllers-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' }>
                                            <li class="link">
                                                <a href="controllers/LinkMetadataFormatGroupController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkMetadataFormatGroupController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' : 'data-bs-target="#xs-injectables-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' :
                                        'id="xs-injectables-links-module-LinkMetadataFormatGroupModule-e3f31c9800a98759c9dbe2eed52997a54ad60e342e2087846372ca7530745333a0e61fc67e4fdda29c87bc52a993957deb49d0aa69641a93ad15e7443c3b57a0"' }>
                                        <li class="link">
                                            <a href="injectables/LinkMetadataFormatGroupService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkMetadataFormatGroupService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/LinkUserGroupModule.html" data-type="entity-link" >LinkUserGroupModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' : 'data-bs-target="#xs-controllers-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' :
                                            'id="xs-controllers-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' }>
                                            <li class="link">
                                                <a href="controllers/EmailServerController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailServerController</a>
                                            </li>
                                            <li class="link">
                                                <a href="controllers/LinkUserGroupController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkUserGroupController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' : 'data-bs-target="#xs-injectables-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' :
                                        'id="xs-injectables-links-module-LinkUserGroupModule-d3b3540a89e17ce1e0db5167256626b219c48663acf9b04924c5dd5a5531d8181dee20bae0b4b9e7197e434541ca1026085db1809399520f0a033c1dd875acec"' }>
                                        <li class="link">
                                            <a href="injectables/EmailServerService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >EmailServerService</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/LinkUserGroupService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >LinkUserGroupService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/ManifestModule.html" data-type="entity-link" >ManifestModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' : 'data-bs-target="#xs-controllers-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' :
                                            'id="xs-controllers-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' }>
                                            <li class="link">
                                                <a href="controllers/ManifestController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ManifestController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' : 'data-bs-target="#xs-injectables-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' :
                                        'id="xs-injectables-links-module-ManifestModule-bb136611c50bfe7b17f08773a033fb521aa27faac16cc09a606e6cdc3fbfadc330e69b3ef7e621281d418b7eb1cbf313e71d32451c037798ab41590adc188a11"' }>
                                        <li class="link">
                                            <a href="injectables/ManifestService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ManifestService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/MediaModule.html" data-type="entity-link" >MediaModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' : 'data-bs-target="#xs-controllers-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' :
                                            'id="xs-controllers-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' }>
                                            <li class="link">
                                                <a href="controllers/MediaController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MediaController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' : 'data-bs-target="#xs-injectables-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' :
                                        'id="xs-injectables-links-module-MediaModule-36c362d9a9ba7e682b558542c72187afcf5dc9c991b2a5b54b9fb8c66e94677d9ddc444f9a0f994ce7b117575c16af1a8746a00591f82b19d4550b3078fdc2db"' }>
                                        <li class="link">
                                            <a href="injectables/MediaService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MediaService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/MetadataFormatModule.html" data-type="entity-link" >MetadataFormatModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' : 'data-bs-target="#xs-controllers-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' :
                                            'id="xs-controllers-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' }>
                                            <li class="link">
                                                <a href="controllers/MetadataFormatController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MetadataFormatController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' : 'data-bs-target="#xs-injectables-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' :
                                        'id="xs-injectables-links-module-MetadataFormatModule-0fd65fd88f5c676dd92198e955551d0e146bbc8fc5f2ed2c514e700238f0721a67c01e50fcd90e1d39217203848c0e8b9cd5437b1a69d30ac0e747ce34ab73f4"' }>
                                        <li class="link">
                                            <a href="injectables/MetadataFormatService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MetadataFormatService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/MetadataModule.html" data-type="entity-link" >MetadataModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' : 'data-bs-target="#xs-controllers-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' :
                                            'id="xs-controllers-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' }>
                                            <li class="link">
                                                <a href="controllers/MetadataController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MetadataController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' : 'data-bs-target="#xs-injectables-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' :
                                        'id="xs-injectables-links-module-MetadataModule-ac1c9720c2fc877614fd2f409d6386f8593b3ac7152770c7c966caa474a1e1bfe6cadaa53197f0a4d08895fd86d4c882dda248531295d639c57e58122f081258"' }>
                                        <li class="link">
                                            <a href="injectables/MetadataService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >MetadataService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/ProjectModule.html" data-type="entity-link" >ProjectModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' : 'data-bs-target="#xs-controllers-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' :
                                            'id="xs-controllers-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' }>
                                            <li class="link">
                                                <a href="controllers/ProjectController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ProjectController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' : 'data-bs-target="#xs-injectables-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' :
                                        'id="xs-injectables-links-module-ProjectModule-482d40ac95e3d43d39ce072e478f81804ec91dca1d4f3c300a685cb8775ceb1119bb913d1c556554d2fc4a560cbb98105f52d2da0fa00cb247a1255a75338a21"' }>
                                        <li class="link">
                                            <a href="injectables/CaslAbilityFactory.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >CaslAbilityFactory</a>
                                        </li>
                                        <li class="link">
                                            <a href="injectables/ProjectService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >ProjectService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/TaggingModule.html" data-type="entity-link" >TaggingModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' : 'data-bs-target="#xs-controllers-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' :
                                            'id="xs-controllers-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' }>
                                            <li class="link">
                                                <a href="controllers/TaggingController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >TaggingController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' : 'data-bs-target="#xs-injectables-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' :
                                        'id="xs-injectables-links-module-TaggingModule-97dd5a4b0c36e0050e9b7e50a9521cca8ff8c94c0ecba25dffbf24d50c4f6ee4ac36fe0c1925c4f523c0be9c6c0ab9f04d2f551a5d037af70153584a16f1dc01"' }>
                                        <li class="link">
                                            <a href="injectables/TaggingService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >TaggingService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/TagModule.html" data-type="entity-link" >TagModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' : 'data-bs-target="#xs-controllers-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' :
                                            'id="xs-controllers-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' }>
                                            <li class="link">
                                                <a href="controllers/TagController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >TagController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' : 'data-bs-target="#xs-injectables-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' :
                                        'id="xs-injectables-links-module-TagModule-6dcbe308f1dbeb0b67cd0554d8595193c3b3586c5b1bcd390f25e87456e6ada7278f2c715e528bc6f3465f98a5d5511ff0c4caa7e1e8122b0ff82dcd0dde2e32"' }>
                                        <li class="link">
                                            <a href="injectables/TagService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >TagService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/UserGroupModule.html" data-type="entity-link" >UserGroupModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' : 'data-bs-target="#xs-controllers-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' :
                                            'id="xs-controllers-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' }>
                                            <li class="link">
                                                <a href="controllers/UserGroupController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UserGroupController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' : 'data-bs-target="#xs-injectables-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' :
                                        'id="xs-injectables-links-module-UserGroupModule-3f9569a4079da8885471db18ffc3e86fb63009dffd8141e3b2be1f1c76b93e7ca7f50cec845642667e090d3484a42e73eca1625580deb96e25684669e932e6f3"' }>
                                        <li class="link">
                                            <a href="injectables/UserGroupService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UserGroupService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/UserManagementModule.html" data-type="entity-link" >UserManagementModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' : 'data-bs-target="#xs-controllers-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' :
                                            'id="xs-controllers-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' }>
                                            <li class="link">
                                                <a href="controllers/UserManagementController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UserManagementController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' : 'data-bs-target="#xs-injectables-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' :
                                        'id="xs-injectables-links-module-UserManagementModule-34d36bd77c1b8f8f1fa2356cdc847a5f75acf951bce17f904f8a577ab6fb4904b653a58c0b4808f9d0f7a46eade6ad03164485adaf9a0c51218bc4a57563f39a"' }>
                                        <li class="link">
                                            <a href="injectables/UserManagementService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UserManagementService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                            <li class="link">
                                <a href="modules/UsersModule.html" data-type="entity-link" >UsersModule</a>
                                    <li class="chapter inner">
                                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                            'data-bs-target="#controllers-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' : 'data-bs-target="#xs-controllers-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' }>
                                            <span class="icon ion-md-swap"></span>
                                            <span>Controllers</span>
                                            <span class="icon ion-ios-arrow-down"></span>
                                        </div>
                                        <ul class="links collapse" ${ isNormalMode ? 'id="controllers-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' :
                                            'id="xs-controllers-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' }>
                                            <li class="link">
                                                <a href="controllers/UsersController.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UsersController</a>
                                            </li>
                                        </ul>
                                    </li>
                                <li class="chapter inner">
                                    <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ?
                                        'data-bs-target="#injectables-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' : 'data-bs-target="#xs-injectables-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' }>
                                        <span class="icon ion-md-arrow-round-down"></span>
                                        <span>Injectables</span>
                                        <span class="icon ion-ios-arrow-down"></span>
                                    </div>
                                    <ul class="links collapse" ${ isNormalMode ? 'id="injectables-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' :
                                        'id="xs-injectables-links-module-UsersModule-3b8665eec5dbafe06c38a3b34ffc8f270848cf7df6f9a28b4400efb8ec395356808e639a1d2bf547e77efcc94bd0ed19b6c6c4a66281ea8c7bdca18196f92198"' }>
                                        <li class="link">
                                            <a href="injectables/UsersService.html" data-type="entity-link" data-context="sub-entity" data-context-id="modules" >UsersService</a>
                                        </li>
                                    </ul>
                                </li>
                            </li>
                </ul>
                </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ? 'data-bs-target="#entities-links"' :
                                'data-bs-target="#xs-entities-links"' }>
                                <span class="icon ion-ios-apps"></span>
                                <span>Entities</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="entities-links"' : 'id="xs-entities-links"' }>
                                <li class="link">
                                    <a href="entities/AnnotationPage.html" data-type="entity-link" >AnnotationPage</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Impersonation.html" data-type="entity-link" >Impersonation</a>
                                </li>
                                <li class="link">
                                    <a href="entities/LinkGroupProject.html" data-type="entity-link" >LinkGroupProject</a>
                                </li>
                                <li class="link">
                                    <a href="entities/LinkManifestGroup.html" data-type="entity-link" >LinkManifestGroup</a>
                                </li>
                                <li class="link">
                                    <a href="entities/LinkMediaGroup.html" data-type="entity-link" >LinkMediaGroup</a>
                                </li>
                                <li class="link">
                                    <a href="entities/LinkMetadataFormatGroup.html" data-type="entity-link" >LinkMetadataFormatGroup</a>
                                </li>
                                <li class="link">
                                    <a href="entities/LinkUserGroup.html" data-type="entity-link" >LinkUserGroup</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Manifest.html" data-type="entity-link" >Manifest</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Media.html" data-type="entity-link" >Media</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Metadata.html" data-type="entity-link" >Metadata</a>
                                </li>
                                <li class="link">
                                    <a href="entities/MetadataFormat.html" data-type="entity-link" >MetadataFormat</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Project.html" data-type="entity-link" >Project</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Tag.html" data-type="entity-link" >Tag</a>
                                </li>
                                <li class="link">
                                    <a href="entities/Tagging.html" data-type="entity-link" >Tagging</a>
                                </li>
                                <li class="link">
                                    <a href="entities/User.html" data-type="entity-link" >User</a>
                                </li>
                                <li class="link">
                                    <a href="entities/UserGroup.html" data-type="entity-link" >UserGroup</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ? 'data-bs-target="#classes-links"' :
                            'data-bs-target="#xs-classes-links"' }>
                            <span class="icon ion-ios-paper"></span>
                            <span>Classes</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="classes-links"' : 'id="xs-classes-links"' }>
                            <li class="link">
                                <a href="classes/AddManifestToGroupDto.html" data-type="entity-link" >AddManifestToGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/AddMediaToGroupDto.html" data-type="entity-link" >AddMediaToGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/AddProjectToGroupDto.html" data-type="entity-link" >AddProjectToGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/ConfirmationEmailDto.html" data-type="entity-link" >ConfirmationEmailDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/ConfirmEmailDto.html" data-type="entity-link" >ConfirmEmailDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateAnnotationPageDto.html" data-type="entity-link" >CreateAnnotationPageDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateEmailServerDto.html" data-type="entity-link" >CreateEmailServerDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateGroupManifestDto.html" data-type="entity-link" >CreateGroupManifestDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateGroupMediaDto.html" data-type="entity-link" >CreateGroupMediaDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateImpersonationDto.html" data-type="entity-link" >CreateImpersonationDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateLinkGroupManifestDto.html" data-type="entity-link" >CreateLinkGroupManifestDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateLinkGroupProjectDto.html" data-type="entity-link" >CreateLinkGroupProjectDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateLinkMediaGroupDto.html" data-type="entity-link" >CreateLinkMediaGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateLinkMetadataFormatGroupDto.html" data-type="entity-link" >CreateLinkMetadataFormatGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateLinkUserGroupDto.html" data-type="entity-link" >CreateLinkUserGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateManifestDto.html" data-type="entity-link" >CreateManifestDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateMediaDto.html" data-type="entity-link" >CreateMediaDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateMetadataDto.html" data-type="entity-link" >CreateMetadataDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateMetadataFormatDto.html" data-type="entity-link" >CreateMetadataFormatDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateProjectDto.html" data-type="entity-link" >CreateProjectDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateTagDto.html" data-type="entity-link" >CreateTagDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateTaggingDto.html" data-type="entity-link" >CreateTaggingDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateUserDto.html" data-type="entity-link" >CreateUserDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CreateUserGroupDto.html" data-type="entity-link" >CreateUserGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/CustomLogger.html" data-type="entity-link" >CustomLogger</a>
                            </li>
                            <li class="link">
                                <a href="classes/DbInit1741707720498.html" data-type="entity-link" >DbInit1741707720498</a>
                            </li>
                            <li class="link">
                                <a href="classes/DbUpdate1742511867850.html" data-type="entity-link" >DbUpdate1742511867850</a>
                            </li>
                            <li class="link">
                                <a href="classes/DbUpdate1742764161651.html" data-type="entity-link" >DbUpdate1742764161651</a>
                            </li>
                            <li class="link">
                                <a href="classes/DeleteParams.html" data-type="entity-link" >DeleteParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/DeleteParams-1.html" data-type="entity-link" >DeleteParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/DeleteResourcePolicy.html" data-type="entity-link" >DeleteResourcePolicy</a>
                            </li>
                            <li class="link">
                                <a href="classes/FindAllParams.html" data-type="entity-link" >FindAllParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/FindOneParams.html" data-type="entity-link" >FindOneParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/FindOneParams-1.html" data-type="entity-link" >FindOneParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/ImpersonateDto.html" data-type="entity-link" >ImpersonateDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/ImpersonationSubscriber.html" data-type="entity-link" >ImpersonationSubscriber</a>
                            </li>
                            <li class="link">
                                <a href="classes/InternalServerErrorFilter.html" data-type="entity-link" >InternalServerErrorFilter</a>
                            </li>
                            <li class="link">
                                <a href="classes/LinkGroupProject.html" data-type="entity-link" >LinkGroupProject</a>
                            </li>
                            <li class="link">
                                <a href="classes/LinkManifestGroup.html" data-type="entity-link" >LinkManifestGroup</a>
                            </li>
                            <li class="link">
                                <a href="classes/LinkMediaGroup.html" data-type="entity-link" >LinkMediaGroup</a>
                            </li>
                            <li class="link">
                                <a href="classes/LinkUserGroup.html" data-type="entity-link" >LinkUserGroup</a>
                            </li>
                            <li class="link">
                                <a href="classes/LockProjectDto.html" data-type="entity-link" >LockProjectDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/loginDto.html" data-type="entity-link" >loginDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/manifestCreationDto.html" data-type="entity-link" >manifestCreationDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/Metadata.html" data-type="entity-link" >Metadata</a>
                            </li>
                            <li class="link">
                                <a href="classes/MetadataFormat.html" data-type="entity-link" >MetadataFormat</a>
                            </li>
                            <li class="link">
                                <a href="classes/Migrations1741706834691.html" data-type="entity-link" >Migrations1741706834691</a>
                            </li>
                            <li class="link">
                                <a href="classes/Migrations1741706945101.html" data-type="entity-link" >Migrations1741706945101</a>
                            </li>
                            <li class="link">
                                <a href="classes/Migrations1741707087986.html" data-type="entity-link" >Migrations1741707087986</a>
                            </li>
                            <li class="link">
                                <a href="classes/Migrations1742511411874.html" data-type="entity-link" >Migrations1742511411874</a>
                            </li>
                            <li class="link">
                                <a href="classes/PatchParams.html" data-type="entity-link" >PatchParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/removeProjectToGroupDto.html" data-type="entity-link" >removeProjectToGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/ResetPasswordEmailDto.html" data-type="entity-link" >ResetPasswordEmailDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/Tagging.html" data-type="entity-link" >Tagging</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateAccessToProjectDto.html" data-type="entity-link" >UpdateAccessToProjectDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateAnnotationPageDto.html" data-type="entity-link" >UpdateAnnotationPageDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateGroupManifestDto.html" data-type="entity-link" >UpdateGroupManifestDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateGroupMediaDto.html" data-type="entity-link" >UpdateGroupMediaDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateImpersonationDto.html" data-type="entity-link" >UpdateImpersonationDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateLinkGroupProjectDto.html" data-type="entity-link" >UpdateLinkGroupProjectDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateLinkMediaGroupDto.html" data-type="entity-link" >UpdateLinkMediaGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateLinkMetadataFormatGroupDto.html" data-type="entity-link" >UpdateLinkMetadataFormatGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateLinkUserGroupDto.html" data-type="entity-link" >UpdateLinkUserGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateManifestDto.html" data-type="entity-link" >UpdateManifestDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateManifestGroupRelation.html" data-type="entity-link" >UpdateManifestGroupRelation</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateManifestJsonDto.html" data-type="entity-link" >UpdateManifestJsonDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateMediaDto.html" data-type="entity-link" >UpdateMediaDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateMediaGroupRelationDto.html" data-type="entity-link" >UpdateMediaGroupRelationDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateMetadataFormatDto.html" data-type="entity-link" >UpdateMetadataFormatDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateParams.html" data-type="entity-link" >UpdateParams</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateProjectDto.html" data-type="entity-link" >UpdateProjectDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateProjectGroupDto.html" data-type="entity-link" >UpdateProjectGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateTagDto.html" data-type="entity-link" >UpdateTagDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateTaggingDto.html" data-type="entity-link" >UpdateTaggingDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateUserDto.html" data-type="entity-link" >UpdateUserDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateUserGroupDto.html" data-type="entity-link" >UpdateUserGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UpdateUserGroupDto-1.html" data-type="entity-link" >UpdateUserGroupDto</a>
                            </li>
                            <li class="link">
                                <a href="classes/UserSubscriber.html" data-type="entity-link" >UserSubscriber</a>
                            </li>
                        </ul>
                    </li>
                        <li class="chapter">
                            <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ? 'data-bs-target="#injectables-links"' :
                                'data-bs-target="#xs-injectables-links"' }>
                                <span class="icon ion-md-arrow-round-down"></span>
                                <span>Injectables</span>
                                <span class="icon ion-ios-arrow-down"></span>
                            </div>
                            <ul class="links collapse " ${ isNormalMode ? 'id="injectables-links"' : 'id="xs-injectables-links"' }>
                                <li class="link">
                                    <a href="injectables/MediaInterceptor.html" data-type="entity-link" >MediaInterceptor</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/MediaLinkInterceptor.html" data-type="entity-link" >MediaLinkInterceptor</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/PolicyFactory.html" data-type="entity-link" >PolicyFactory</a>
                                </li>
                                <li class="link">
                                    <a href="injectables/SharpPipeInterceptor.html" data-type="entity-link" >SharpPipeInterceptor</a>
                                </li>
                            </ul>
                        </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ? 'data-bs-target="#guards-links"' :
                            'data-bs-target="#xs-guards-links"' }>
                            <span class="icon ion-ios-lock"></span>
                            <span>Guards</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="guards-links"' : 'id="xs-guards-links"' }>
                            <li class="link">
                                <a href="guards/AuthGuard.html" data-type="entity-link" >AuthGuard</a>
                            </li>
                            <li class="link">
                                <a href="guards/PoliciesGuard.html" data-type="entity-link" >PoliciesGuard</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ? 'data-bs-target="#interfaces-links"' :
                            'data-bs-target="#xs-interfaces-links"' }>
                            <span class="icon ion-md-information-circle-outline"></span>
                            <span>Interfaces</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? ' id="interfaces-links"' : 'id="xs-interfaces-links"' }>
                            <li class="link">
                                <a href="interfaces/AuthenticatedRequest.html" data-type="entity-link" >AuthenticatedRequest</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/IPolicyHandler.html" data-type="entity-link" >IPolicyHandler</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/MailService.html" data-type="entity-link" >MailService</a>
                            </li>
                            <li class="link">
                                <a href="interfaces/Policy.html" data-type="entity-link" >Policy</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <div class="simple menu-toggler" data-bs-toggle="collapse" ${ isNormalMode ? 'data-bs-target="#miscellaneous-links"'
                            : 'data-bs-target="#xs-miscellaneous-links"' }>
                            <span class="icon ion-ios-cube"></span>
                            <span>Miscellaneous</span>
                            <span class="icon ion-ios-arrow-down"></span>
                        </div>
                        <ul class="links collapse " ${ isNormalMode ? 'id="miscellaneous-links"' : 'id="xs-miscellaneous-links"' }>
                            <li class="link">
                                <a href="miscellaneous/enumerations.html" data-type="entity-link">Enums</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/functions.html" data-type="entity-link">Functions</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/typealiases.html" data-type="entity-link">Type aliases</a>
                            </li>
                            <li class="link">
                                <a href="miscellaneous/variables.html" data-type="entity-link">Variables</a>
                            </li>
                        </ul>
                    </li>
                    <li class="chapter">
                        <a data-type="chapter-link" href="coverage.html"><span class="icon ion-ios-stats"></span>Documentation coverage</a>
                    </li>
                    <li class="divider"></li>
                    <li class="copyright">
                        Documentation generated using <a href="https://compodoc.app/" target="_blank" rel="noopener noreferrer">
                            <img data-src="images/compodoc-vectorise.png" class="img-responsive" data-type="compodoc-logo">
                        </a>
                    </li>
            </ul>
        </nav>
        `);
        this.innerHTML = tp.strings;
    }
});